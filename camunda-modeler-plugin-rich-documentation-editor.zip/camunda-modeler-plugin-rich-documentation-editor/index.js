/**
 * Menu entries, styles and scripts are all optional. Feel free to delete them
 * here along their respective folders (client and dist for style) if you don't need them.
 * */

'use strict';

module.exports = {
  name: 'Rich Element Documentation Editor Plug-in',
  script: './dist/client.js',
  style: './style/style.css',
};
